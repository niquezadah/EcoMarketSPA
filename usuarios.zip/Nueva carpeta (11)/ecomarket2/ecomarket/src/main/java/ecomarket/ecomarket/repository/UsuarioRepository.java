package ecomarket.ecomarket.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ecomarket.ecomarket.model.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
}