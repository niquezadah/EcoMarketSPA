package ecomarket.ecomarket.model;

public enum Role {
    CLIENTE,
    EMPLEADO
}