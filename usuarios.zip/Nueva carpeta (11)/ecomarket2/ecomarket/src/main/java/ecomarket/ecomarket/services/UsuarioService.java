package ecomarket.ecomarket.services;


import java.util.List;

import org.springframework.stereotype.Service;

import ecomarket.ecomarket.model.Usuario;
import ecomarket.ecomarket.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor

public class UsuarioService {

    private final UsuarioRepository repository;

    public Usuario guardarUsuario(Usuario usuario) {
        return repository.save(usuario);
    }

    public List<Usuario> listarUsuarios() {
        return repository.findAll();
    }
}